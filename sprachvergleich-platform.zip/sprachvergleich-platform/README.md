# Kontrastive Linguistik DE ↔ TR — DaZ-Lernplattform

Eine interaktive Single-Page-Plattform für den **Sprachvergleich Deutsch / Türkisch**
mit didaktischem Fokus auf **Deutsch als Zweitsprache (DaZ)** und die DaZ-Lehramtsausbildung.

**Konzept, Inhalt & alle Rechte: Dr. Ergun Özsoy · LMU München · ALM 260 (Karşılaştırmalı Dilbilgisi).**

---

## Didaktisches Modell — 5 Schritte je Thema

1. **Kontrastiver Befund** — Deutsch | Türkisch nebeneinander
2. **Didaktik & DaZ-Relevanz**
3. **Interferenzanalyse** — Fehler · muttersprachliche Quelle · Fehlerkategorie (n. Thomé 1987)
4. **Korrektur & Förderung**
5. **Interkulturalität & Mehrsprachigkeit als Ressource**

Theoretischer Rahmen: **Lernersprache-/Interlanguage-Hypothese** (nicht die widerlegte
Kontrastivhypothese). Fehler werden in *systematisch* (intralingual) vs. *interferenzbedingt*
(interlingual) unterschieden.

---

## Dateien

```
index.html                          ← die Plattform (alles inline, keine Build-Tools)
themen/                             ← Themen-Dossiers als PDF (pro Einheit)
  auslautverhaertung.pdf
  genus-artikel.pdf
arbeitsblaetter/                    ← DaZ-Arbeitsblätter / Worksheets als PDF (+ Lösungen)
  ab_auslautverhaertung.pdf
  ab_genus-artikel.pdf
gen_pdfs.py                         ← erzeugt alle PDFs neu (WeasyPrint)
requirements.txt
.github/workflows/build-pdfs.yml   ← baut die PDFs bei jedem Push automatisch
```

## Online stellen (GitHub Pages)

1. Neues Repository anlegen, den **gesamten Ordnerinhalt** ins Wurzelverzeichnis hochladen.
2. **Settings → Pages → Branch: `main` / root → Save.**
3. Nach ~1 Min. erreichbar unter `https://<user>.github.io/<repo>/`.

Die PDFs liegen relativ daneben (`themen/…`, `arbeitsblaetter/…`) — die Download-Buttons
funktionieren sofort.

## PDFs neu erzeugen

Lokal:
```bash
pip install -r requirements.txt
python gen_pdfs.py
```
Oder automatisch: Die mitgelieferte GitHub-Action (`.github/workflows/build-pdfs.yml`) baut
bei jedem Push in `gen_pdfs.py` alle PDFs neu und committet sie zurück.

## Neues Thema ergänzen

Pro Thema zwei Stellen pflegen:

- **`index.html` → `MODULES`**: Eintrag in der passenden `topics[]`-Liste; `s:"draft"`
  zeigt das Thema (ausgegraut), `s:"ready"` schaltet es frei.
- **`index.html` → `DETAIL`**: die fünf Blöcke (als HTML-Strings) je Thema. Ein vorhandenes
  „ready"-Thema kopieren und überschreiben.
- **`gen_pdfs.py`**: einen `topic_dossier(...)`-Block ergänzen → erzeugt das PDF.

## Status (Pilot)

| Modul | Thema | Web | PDF | Arbeitsblatt |
|------|-------|-----|-----|--------------|
| I | Auslautverhärtung | ✅ | ✅ | ✅ |
| II | Genus & Artikel | ✅ | ✅ | ✅ |
| I–III | übrige Themen | ⬜ in Vorbereitung | — | — |

---
© Dr. Ergun Özsoy — alle Rechte vorbehalten. Theoretische Quellen (Buchberger/KALIPHO,
Balcı, Johanson, Ersen-Rasch u. a.) dienen ausschließlich als Referenzmaterial.
