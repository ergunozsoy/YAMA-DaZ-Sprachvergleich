# -*- coding: utf-8 -*-
"""
Erzeugt die herunterladbaren PDF-Dossiers (pro Thema) und die DaZ-Arbeitsblätter.
Quelle: ALM 260 / Sprachvergleich DE-TR (Dr. Ergun Özsoy, LMU München).
Didaktisches Modell: 5 Schritte je Thema (Lernersprache-Hypothese).
"""
import os, datetime
from weasyprint import HTML

OUT = "/home/claude/platform"
os.makedirs(f"{OUT}/themen", exist_ok=True)
os.makedirs(f"{OUT}/arbeitsblaetter", exist_ok=True)

GREEN  = "#00883A"
GOLD   = "#C8A45C"
INK    = "#222629"
DATE   = datetime.date.today().strftime("%d.%m.%Y")

# ---------------------------------------------------------------------------
#  PRINT-CSS (gemeinsam)
# ---------------------------------------------------------------------------
CSS = f"""
@page {{
  size: A4; margin: 20mm 18mm 22mm 18mm;
  @top-left {{ content: "Kontrastive Linguistik DE \\2194 TR"; font: 8pt 'Georgia',serif; color:#888; }}
  @top-right {{ content: "ALM 260 \\00B7 LMU M\\00FCnchen"; font: 8pt 'Georgia',serif; color:#888; }}
  @bottom-left {{ content: "\\00A9 Dr. Ergun \\00D6zsoy \\2013 alle Rechte vorbehalten"; font:8pt sans-serif; color:#999; }}
  @bottom-right {{ content: "Seite " counter(page) " / " counter(pages); font:8pt sans-serif; color:#999; }}
}}
* {{ box-sizing:border-box; }}
body {{ font-family:'Calibri','Segoe UI',sans-serif; color:{INK}; font-size:10.5pt; line-height:1.5; }}
h1,h2,h3 {{ font-family:'Georgia','Times New Roman',serif; color:{GREEN}; line-height:1.25; }}
.brandbar {{ height:6px; background:{GREEN}; border-radius:3px; margin-bottom:4mm; }}
.brandbar.gold {{ background:{GOLD}; }}
.kicker {{ font-size:8.5pt; letter-spacing:.12em; text-transform:uppercase; color:{GOLD}; font-weight:700; }}
h1 {{ font-size:21pt; margin:1mm 0 1mm; }}
.lead {{ color:#555; font-size:10.5pt; margin:0 0 5mm; }}
.block {{ border:1px solid #e3e3e3; border-left:4px solid {GREEN}; border-radius:6px; padding:4mm 5mm; margin:0 0 5mm; break-inside:avoid; }}
.block .num {{ display:inline-block; min-width:18px; color:{GOLD}; font-weight:700; font-family:'Georgia',serif; }}
.block h2 {{ font-size:13pt; margin:0 0 2mm; }}
table {{ width:100%; border-collapse:collapse; margin:2mm 0; font-size:9.8pt; }}
th,td {{ border:1px solid #dcdcdc; padding:2.2mm 3mm; text-align:left; vertical-align:top; }}
th {{ background:#f3f6f3; color:{GREEN}; font-family:'Georgia',serif; }}
td.de {{ background:#fbfdfb; }} td.tr {{ background:#fdfbf6; }}
.ex {{ font-family:'Consolas','Courier New',monospace; }}
.err {{ color:#b3261e; text-decoration:line-through; }}
.ok  {{ color:{GREEN}; font-weight:600; }}
.tag {{ display:inline-block; font-size:8pt; padding:1px 7px; border-radius:10px; background:#eef3ee; color:{GREEN}; border:1px solid #cfe0cf; }}
.tag.cat {{ background:#f6efe1; color:#8a6b22; border-color:#e6d4a6; }}
ul {{ margin:1mm 0 1mm 5mm; padding:0; }}
li {{ margin:1mm 0; }}
.note {{ font-size:9pt; color:#666; font-style:italic; }}
.foot {{ margin-top:6mm; padding-top:3mm; border-top:1px solid #e3e3e3; font-size:8.5pt; color:#888; }}
.task {{ border:1px solid #e3e3e3; border-radius:6px; padding:3.5mm 4mm; margin:0 0 4mm; break-inside:avoid; }}
.task h3 {{ font-size:11.5pt; margin:0 0 1.5mm; color:{INK}; }}
.task .meta {{ font-size:8.5pt; color:{GOLD}; font-weight:700; text-transform:uppercase; letter-spacing:.08em; }}
.line {{ border-bottom:1px solid #bbb; min-height:6mm; }}
.sol {{ background:#f3f6f3; border-left:4px solid {GOLD}; }}
.badge {{ font-family:'Georgia',serif; color:{GREEN}; font-weight:700; }}
"""

def render(path, inner, gold=False):
    html = f"""<!doctype html><html lang="de"><head><meta charset="utf-8">
    <style>{CSS}</style></head><body>
    <div class="brandbar {'gold' if gold else ''}"></div>{inner}</body></html>"""
    HTML(string=html).write_pdf(path)
    print("  ->", path.split("/")[-1], os.path.getsize(path), "B")

# ===========================================================================
#  THEMEN-DOSSIERS  (5-Schritte-Modell)
# ===========================================================================

def topic_dossier(meta, blocks):
    """blocks: list of (titel, html_inhalt) — genau 5 (Kontrastiver Befund …)."""
    parts = [f"""
      <div class="kicker">{meta['modul']} &middot; ALM 260 Sprachvergleich</div>
      <h1>{meta['titel']}</h1>
      <p class="lead">{meta['lead']}</p>"""]
    names = ["Kontrastiver Befund","Didaktik &amp; DaZ-Relevanz",
             "Interferenzanalyse","Korrektur &amp; F&ouml;rderung",
             "Interkulturalit&auml;t &amp; Mehrsprachigkeit als Ressource"]
    for i,(_,inhalt) in enumerate(blocks):
        parts.append(f"""<div class="block">
          <h2><span class="num">{i+1}</span>{names[i]}</h2>{inhalt}</div>""")
    parts.append(f"""<div class="foot">
      <b>Theoretischer Rahmen:</b> Lernersprache-/Interlanguage-Hypothese &ndash;
      Fehler werden als <i>systematisch</i> (intralingual) vs. <i>interferenzbedingt</i>
      (interlingual) unterschieden; Mehrsprachigkeit gilt als Ressource, nicht als Defizit.<br>
      Fehlerkategorien nach Thom&eacute; (1987). &middot; Stand: {DATE} &middot;
      Konzept &amp; Inhalt: Dr. Ergun &Ouml;zsoy, LMU M&uuml;nchen.</div>""")
    return "".join(parts)

# ---- Thema 1: Auslautverhärtung -------------------------------------------
auslaut = topic_dossier(
  {"modul":"Modul I &middot; Laut &amp; Schrift",
   "titel":"Auslautverh&auml;rtung",
   "lead":"Beide Sprachen entstimmen Plosive am Wort-/Silbenende &ndash; aber sie "
          "verschriften das Ergebnis unterschiedlich. Genau hier entsteht ein "
          "orthographischer Interferenzfehler."},
  [
   ("Kontrastiver Befund", """
     <table><tr><th>Merkmal</th><th>Deutsch</th><th>T&uuml;rkisch</th></tr>
     <tr><td>Phonolog. Prozess</td><td class="de">Auslautverh&auml;rtung aller stimmhaften
        Obstruenten: <span class="ex">/b d g/&rarr;[p t k]</span></td>
        <td class="tr">Finale Entstimmung der Plosive
        <span class="ex">/b d c g/&rarr;[p t &ccedil; k]</span></td></tr>
     <tr><td>Beispiel gesprochen</td><td class="de"><span class="ex">Tag</span> [ta&#720;k],
        <span class="ex">Hund</span> [h&#650;nt], <span class="ex">lieb</span> [li&#720;p]</td>
        <td class="tr"><span class="ex">kitap</span> [kitap],
        <span class="ex">renk</span> [re&#331;k]</td></tr>
     <tr><td>Verschriftung</td><td class="de"><b>morphophonemisch</b>: das stimmhafte
        Graphem bleibt (<span class="ex">Tag&middot;e, lieb&middot;e</span>)</td>
        <td class="tr"><b>oberfl&auml;chenphonemisch</b>: man schreibt das Geh&ouml;rte
        (<span class="ex">kitap</span>, aber <span class="ex">kitab&#305;</span>)</td></tr></table>
     <p class="note">Kernpunkt: Den <i>Laut</i> kennen t&uuml;rkischsprachige Lernende bereits &ndash;
        nur die <i>Schreibkonvention</i> ist neu.</p>"""),
   ("Didaktik", """
     <p>Die Auslautverh&auml;rtung ist im DaZ-Unterricht doppelt relevant: f&uuml;r die
       <b>Rechtschreibung</b> (richtiges Endgraphem) und f&uuml;r das <b>Leseverstehen</b>
       (Wortverwandtschaften erkennen: <span class="ex">Tag&ndash;t&auml;glich&ndash;Tage</span>).
       Sie geh&ouml;rt zu den fr&uuml;h zu sichernden Rechtschreibstrategien (Klasse 1&ndash;4 bzw.
       Alphabetisierung im DaZ).</p>"""),
   ("Interferenzanalyse", """
     <table><tr><th>Lernerschreibung</th><th>Zielform</th><th>Quelle (L1)</th><th>Kategorie</th></tr>
     <tr><td><span class="err">Hunt</span></td><td><span class="ok">Hund</span></td>
       <td>phonemische TR-Orthographie: &bdquo;schreib, was du h&ouml;rst&ldquo;</td>
       <td><span class="tag cat">Graphem-Phonem</span></td></tr>
     <tr><td><span class="err">Tak</span></td><td><span class="ok">Tag</span></td>
       <td>finale Entstimmung wird verschriftet</td>
       <td><span class="tag cat">Graphem-Phonem</span></td></tr>
     <tr><td><span class="err">lip</span></td><td><span class="ok">lieb</span></td>
       <td>L1-Konvention auf L2 &uuml;bertragen</td>
       <td><span class="tag cat">interferenzbedingt</span></td></tr></table>
     <p class="note">Abgrenzung: Dies ist <b>interferenzbedingt</b> (L1-Schreibkonvention),
       nicht bloss intralingual &ndash; die Lernenden &bdquo;h&ouml;ren richtig&ldquo;,
       verschriften aber nach L1-Logik.</p>"""),
   ("Korrektur", """
     <p><b>Verl&auml;ngerungsprobe (Ableitungsprobe).</b> Das Wort wird so verl&auml;ngert,
       dass der Auslaut in den Anlaut der n&auml;chsten Silbe r&uuml;ckt und stimmhaft wird &ndash;
       das verr&auml;t das richtige Graphem:</p>
     <ul>
       <li><span class="ex">Hund &rarr; Hun<b>d</b>e</span> &nbsp;&rarr;&nbsp; <span class="ok">d</span></li>
       <li><span class="ex">Tag &rarr; Ta<b>g</b>e</span> &nbsp;&rarr;&nbsp; <span class="ok">g</span></li>
       <li><span class="ex">lieb &rarr; lie<b>b</b>er</span> &nbsp;&rarr;&nbsp; <span class="ok">b</span></li>
     </ul>
     <p>Routine: <i>verl&auml;ngern &rarr; h&ouml;ren &rarr; Graphem festhalten</i>.
        Parallele zum T&uuml;rkischen explizit machen:
        <span class="ex">kitap&ndash;kitab&#305;</span> zeigt denselben Wechsel &ndash; nur dort wird er
        <i>geschrieben</i>.</p>"""),
   ("Interkulturalität", """
     <p>Die L1 ist hier ein <b>Vorsprung</b>, kein Hindernis: Der phonologische Prozess der
       finalen Entstimmung existiert im T&uuml;rkischen bereits
       (<span class="ex">kitap/kitab&#305;, renk/rengi</span>). Lernende besitzen also das
       n&ouml;tige Lautgef&uuml;hl. Reframing der Aufgabe: nicht &bdquo;ein neuer Laut&ldquo;,
       sondern &bdquo;eine andere <i>Schreibregel</i> f&uuml;r denselben Laut&ldquo;. So wird
       Mehrsprachigkeit zur Ressource &ndash; der TR-Wechsel <span class="ex">p/b</span> dient als
       Br&uuml;cke zur deutschen Verl&auml;ngerungsprobe.</p>"""),
  ])
render(f"{OUT}/themen/auslautverhaertung.pdf", auslaut)

# ---- Thema 2: Genus & Artikel ---------------------------------------------
genus = topic_dossier(
  {"modul":"Modul II &middot; Morphologie (Nomen)",
   "titel":"Genus &amp; Artikel",
   "lead":"Das Deutsche markiert Genus (der/die/das) und Bestimmtheit am Artikel &ndash; "
          "das T&uuml;rkische kennt weder grammatisches Genus noch Artikel. Eine der "
          "hartn&auml;ckigsten DaZ-Fehlerquellen."},
  [
   ("Kontrastiver Befund", """
     <table><tr><th>Kategorie</th><th>Deutsch</th><th>T&uuml;rkisch</th></tr>
     <tr><td>Grammatisches Genus</td><td class="de">3 Genera, lexikalisch fest:
        <span class="ex">der Tisch, die Lampe, das Buch</span></td>
        <td class="tr">kein Genus &ndash; ein Wort f&uuml;r &bdquo;er/sie/es&ldquo;:
        <span class="ex">o</span></td></tr>
     <tr><td>Bestimmter Artikel</td><td class="de"><span class="ex">der/die/das</span></td>
        <td class="tr">keiner; Bestimmtheit u.&nbsp;a. &uuml;ber den
        <b>Akkusativ</b> (<span class="ex">-i</span>) &amp; Wortstellung</td></tr>
     <tr><td>Unbestimmter Artikel</td><td class="de"><span class="ex">ein/eine/ein</span></td>
        <td class="tr">optional <span class="ex">bir</span> (&bdquo;ein&ldquo;)</td></tr>
     <tr><td>Bestimmtheit am Objekt</td>
        <td class="de"><span class="ex">Ich lese <b>das</b> Buch</span> (Artikel)</td>
        <td class="tr"><span class="ex">Kitab<b>&#305;</b> okuyorum</span> (Akkusativ-Suffix
        markiert das <i>bestimmte</i> Objekt)</td></tr></table>
     <p class="note">Funktional ist Bestimmtheit also in <i>beiden</i> Sprachen vorhanden &ndash;
        nur die Kodierung unterscheidet sich: Artikel (DE) vs. Kasus/Wortstellung (TR).</p>"""),
   ("Didaktik", """
     <p>Genus ist nicht ableitbar und muss <b>mit jedem Nomen mitgelernt</b> werden
       (Nomen + Artikel als Einheit). Da die L1 die Kategorie nicht besitzt, fehlt die
       intuitive St&uuml;tze &ndash; Genus- und Artikelfehler bleiben oft bis in
       fortgeschrittene Niveaus bestehen und sind damit ein <b>diagnostischer Dauerbrenner</b>
       der DaZ-Lehrkraft.</p>"""),
   ("Interferenzanalyse", """
     <table><tr><th>Lerner&auml;usserung</th><th>Zielform</th><th>Quelle (L1)</th><th>Kategorie</th></tr>
     <tr><td><span class="err">Ich sehe Mann.</span></td><td><span class="ok">Ich sehe einen Mann.</span></td>
       <td>L1 hat keinen obligatorischen Artikel</td>
       <td><span class="tag cat">Auslassung / interferenzbedingt</span></td></tr>
     <tr><td><span class="err">der M&auml;dchen</span></td><td><span class="ok">das M&auml;dchen</span></td>
       <td>kein Genus in L1 &rarr; Zuweisung zuf&auml;llig/semantisch</td>
       <td><span class="tag cat">Genuszuweisung</span></td></tr>
     <tr><td><span class="err">Ich kaufe ein Brot</span> (gemeint: best.)</td>
       <td><span class="ok">Ich kaufe das Brot</span></td>
       <td>Bestimmtheit in L1 &uuml;ber Kasus, nicht Artikel</td>
       <td><span class="tag cat">Bestimmtheit</span></td></tr></table>
     <p class="note">Wichtig: Artikelfehler sind teils <b>interferenzbedingt</b> (fehlende
       L1-Kategorie), teils <b>systematisch</b> (Genus-&Uuml;bergeneralisierung). Die Diagnose
       trennt beides.</p>"""),
   ("Korrektur", """
     <p><b>1. Nomen-Artikel-Kopplung:</b> Vokabeln nie ohne Artikel lernen; Farbcode
       (<span style="color:#1565c0">der</span>/<span style="color:#c62828">die</span>/<span style="color:#2e7d32">das</span>).</p>
     <p><b>2. Genus-Heuristiken</b> (nicht 100&nbsp;%, aber tragf&auml;hig):</p>
     <ul>
       <li><span class="ex">-ung, -heit, -keit, -schaft, -tion, -e</span> &rarr; meist
           <span class="ok">die</span></li>
       <li><span class="ex">-chen, -lein, -ment, -um</span> &rarr; <span class="ok">das</span></li>
       <li>Agens auf <span class="ex">-er</span>, Tageszeiten/Jahreszeiten &rarr;
           <span class="ok">der</span></li>
     </ul>
     <p><b>3. Bestimmtheit kontrastiv</b>: TR <span class="ex">-i</span>/<span class="ex">bir</span>
       gezielt auf DE <span class="ex">das</span>/<span class="ex">ein</span> abbilden.</p>"""),
   ("Interkulturalität", """
     <p>Auch wenn dem T&uuml;rkischen Artikel und Genus fehlen, <b>grammatikalisiert es
       Bestimmtheit sehr wohl</b> &ndash; &uuml;ber das Akkusativsuffix
       <span class="ex">-i</span> (bestimmtes Objekt) und die Wortstellung. Lernende besitzen
       also bereits das <i>Konzept</i> &bdquo;bestimmt vs. unbestimmt&ldquo;, nur an anderer
       Stelle kodiert. Diese vorhandene Kompetenz wird zur Br&uuml;cke: Der Artikel ist dann
       nicht eine fremde Pflicht, sondern die deutsche <i>Bauform</i> einer Funktion, die die
       Lernenden l&auml;ngst beherrschen. Mehrsprachigkeit als Ressource &ndash; nicht als
       Mangel.</p>"""),
  ])
render(f"{OUT}/themen/genus-artikel.pdf", genus)

# ===========================================================================
#  ARBEITSBLÄTTER (DaZ)
# ===========================================================================

def worksheet(meta, intro, tasks, solutions):
    head = f"""
      <div class="kicker">DaZ-Arbeitsblatt &middot; {meta['modul']}</div>
      <h1>{meta['titel']}</h1>
      <p class="lead">{meta['niveau']} &middot; {meta['ziel']}</p>
      <p>{intro}</p>"""
    body = "".join(
       f"""<div class="task"><div class="meta">Aufgabe {i+1} &middot; {t['typ']}</div>
            <h3>{t['titel']}</h3>{t['html']}</div>""" for i,t in enumerate(tasks))
    sol = f"""<div style="break-before:page"></div>
       <div class="brandbar gold"></div>
       <div class="kicker">L&ouml;sungsschl&uuml;ssel</div>
       <h1 style="font-size:17pt">L&ouml;sungen &amp; Lehrerhinweise</h1>{solutions}"""
    foot = f"""<div class="foot">DaZ-Material zum Sprachvergleich DE&ndash;TR &middot;
        Konzept: Dr. Ergun &Ouml;zsoy, LMU M&uuml;nchen &middot; Stand: {DATE}</div>"""
    return head + body + foot + sol

# ---- AB 1: Auslautverhärtung ----------------------------------------------
ab1 = worksheet(
  {"modul":"Laut &amp; Schrift","titel":"Auslautverh&auml;rtung &ndash; richtig h&ouml;ren, richtig schreiben",
   "niveau":"A2&ndash;B1 / Alphabetisierung","ziel":"Rechtschreibstrategie &bdquo;Verl&auml;ngern&ldquo;"},
  "Im Deutschen spricht man am Wortende oft [p t k], schreibt aber <b>b d g</b>. "
  "Verl&auml;ngere das Wort, dann h&ouml;rst du den richtigen Buchstaben.",
  [
   {"typ":"Verl&auml;ngern","titel":"Finde das richtige Endgraphem","html":"""
     <p>Verl&auml;ngere und entscheide: <b>b/p</b>, <b>d/t</b> oder <b>g/k</b>?</p>
     <table><tr><th>Wort</th><th>verl&auml;ngert &rarr;</th><th>Endbuchstabe</th></tr>
     <tr><td class="ex">Hun__</td><td class="line"></td><td class="line"></td></tr>
     <tr><td class="ex">Ta__</td><td class="line"></td><td class="line"></td></tr>
     <tr><td class="ex">lie__</td><td class="line"></td><td class="line"></td></tr>
     <tr><td class="ex">Kor__ (Korb)</td><td class="line"></td><td class="line"></td></tr>
     <tr><td class="ex">Zu__ (Zug)</td><td class="line"></td><td class="line"></td></tr></table>"""},
   {"typ":"Fehler korrigieren","titel":"Verbessere die Schreibung","html":"""
     <p>Diese Schreibungen folgen der t&uuml;rkischen Regel &bdquo;schreib, was du h&ouml;rst&ldquo;.
        Schreibe die deutsche Form daneben.</p>
     <table><tr><th>falsch</th><th>richtig</th></tr>
     <tr><td class="ex">der Hunt</td><td class="line"></td></tr>
     <tr><td class="ex">am Tak</td><td class="line"></td></tr>
     <tr><td class="ex">das Kint</td><td class="line"></td></tr>
     <tr><td class="ex">der Berk</td><td class="line"></td></tr></table>"""},
   {"typ":"Kontrastiv","titel":"Br&uuml;cke zum T&uuml;rkischen","html":"""
     <p>Im T&uuml;rkischen wechselt der Laut auch &ndash; aber man <i>schreibt</i> ihn:
        <span class="ex">kitap &ndash; kitab&#305;</span>. Erg&auml;nze nach dem Muster und
        markiere, wo Deutsch das Graphem <b>beh&auml;lt</b>:</p>
     <p class="ex">Tag &ndash; Ta__e &nbsp;|&nbsp; Hund &ndash; Hun__e &nbsp;|&nbsp; lieb &ndash; lie__er</p>"""},
  ],
  """<ul>
     <li><b>A1:</b> Hun<b>d</b> (Hunde) &middot; Ta<b>g</b> (Tage) &middot; lie<b>b</b> (lieber) &middot;
         Kor<b>b</b> (K&ouml;rbe) &middot; Zu<b>g</b> (Z&uuml;ge).</li>
     <li><b>A2:</b> Hund &middot; Tag &middot; Kind &middot; Berg.</li>
     <li><b>A3:</b> Ta<b>g</b>e &middot; Hun<b>d</b>e &middot; lie<b>b</b>er &ndash; das Graphem
         (b/d/g) bleibt; Deutsch verschriftet morphophonemisch, T&uuml;rkisch
         oberfl&auml;chenphonemisch.</li>
     <li class="note"><b>Hinweis:</b> Den Prozess (finale Entstimmung) kennen die Lernenden aus
         dem T&uuml;rkischen. Thematisieren Sie nur die <i>Schreibkonvention</i> &ndash; das
         entlastet und nutzt die L1 als Ressource.</li></ul>""")
render(f"{OUT}/arbeitsblaetter/ab_auslautverhaertung.pdf", ab1, gold=True)

# ---- AB 2: Genus & Artikel ------------------------------------------------
ab2 = worksheet(
  {"modul":"Nomen","titel":"Genus, Artikel &amp; Bestimmtheit","niveau":"A2&ndash;B1",
   "ziel":"Artikel sichern, Bestimmtheit kontrastiv verstehen"},
  "Das T&uuml;rkische hat keinen Artikel und kein Genus. Diese &Uuml;bungen sichern "
  "<b>der/die/das</b> und zeigen, wie das T&uuml;rkische Bestimmtheit anders ausdr&uuml;ckt.",
  [
   {"typ":"Genus-Heuristik","titel":"der, die oder das?","html":"""
     <p>Nutze die Endungen-Regeln. Trage den Artikel ein.</p>
     <table><tr><th>Nomen</th><th>Artikel</th><th>Nomen</th><th>Artikel</th></tr>
     <tr><td class="ex">Zeitung</td><td class="line"></td><td class="ex">M&auml;dchen</td><td class="line"></td></tr>
     <tr><td class="ex">Freiheit</td><td class="line"></td><td class="ex">Lehrer</td><td class="line"></td></tr>
     <tr><td class="ex">Nation</td><td class="line"></td><td class="ex">Dokument</td><td class="line"></td></tr>
     <tr><td class="ex">Freundschaft</td><td class="line"></td><td class="ex">Sommer</td><td class="line"></td></tr></table>"""},
   {"typ":"Fehler korrigieren","titel":"Artikel erg&auml;nzen / korrigieren","html":"""
     <p>Typische Auslassungen. Schreibe den Satz richtig.</p>
     <table><tr><th>Lernersatz</th><th>korrekt</th></tr>
     <tr><td class="ex">Ich sehe Mann.</td><td class="line"></td></tr>
     <tr><td class="ex">der M&auml;dchen lacht.</td><td class="line"></td></tr>
     <tr><td class="ex">Ich brauche Buch.</td><td class="line"></td></tr></table>"""},
   {"typ":"Kontrastiv","titel":"Bestimmtheit: T&uuml;rkisch &harr; Deutsch","html":"""
     <p>Im T&uuml;rkischen zeigt das Suffix <span class="ex">-i</span> ein <b>bestimmtes</b>
        Objekt. Ordne zu, ob Deutsch <span class="ex">das/den</span> (bestimmt) oder
        <span class="ex">ein/einen</span> (unbestimmt) braucht:</p>
     <table><tr><th>T&uuml;rkisch</th><th>Deutsch (erg&auml;nze Artikel)</th></tr>
     <tr><td class="ex">Kitab&#305; okuyorum.</td><td>Ich lese ____ Buch.</td></tr>
     <tr><td class="ex">Bir kitap okuyorum.</td><td>Ich lese ____ Buch.</td></tr>
     <tr><td class="ex">Adam&#305; g&ouml;r&uuml;yorum.</td><td>Ich sehe ____ Mann.</td></tr></table>"""},
  ],
  """<ul>
     <li><b>A1:</b> die Zeitung &middot; das M&auml;dchen &middot; die Freiheit &middot; der Lehrer &middot;
         die Nation &middot; das Dokument &middot; die Freundschaft &middot; der Sommer.</li>
     <li><b>A2:</b> Ich sehe <b>einen</b> Mann. &middot; <b>Das</b> M&auml;dchen lacht. &middot;
         Ich brauche <b>ein</b> Buch.</li>
     <li><b>A3:</b> <b>das</b> Buch (best., TR <span class="ex">-&#305;</span>) &middot;
         <b>ein</b> Buch (unbest., TR <span class="ex">bir</span>) &middot;
         <b>den</b> Mann (best. Akk., TR <span class="ex">-&#305;</span>).</li>
     <li class="note"><b>Hinweis:</b> A3 macht die Funktion sichtbar: Die Lernenden kennen
         Bestimmtheit aus dem T&uuml;rkischen (Kasus), sie m&uuml;ssen sie nur deutsch
         <i>umkodieren</i> (Artikel). Das ist die interkulturelle Br&uuml;cke.</li></ul>""")
render(f"{OUT}/arbeitsblaetter/ab_genus-artikel.pdf", ab2, gold=True)

print("\nFERTIG.")
